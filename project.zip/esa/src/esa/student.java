package esa;

import java.sql.*;

public class student {
	static int sid1;
    static String sname1;
    static String clsrm1;
    static  int seatno1;
    static String pswd1;
    static String branch1;
    
	public static void studentloginanddisplay(Statement stmt,int studentid,String studentpswd)
	{
		int count=0;

		try {
	      ResultSet rs1=stmt.executeQuery("select * from Student_Details");
	      
  

     
	      while(rs1.next())
	      {
     	    sid1=rs1.getInt("id");
     	    pswd1=rs1.getString("password");
     	    branch1=rs1.getString("branch");
     	    sname1=rs1.getString("name");
     	    clsrm1=rs1.getString("classroom");
     	    seatno1=rs1.getInt("seat");
            
 	    	
     	    if(sid1==studentid  &&  pswd1.equals(studentpswd))
     	      {

    	    	 System.out.println("STUDENT ID    BRANCH    CLASSROOM    SEAT NUMBER   STUDENT NAME");
    	    	/* String sql="update Student_Details set branch='"+studentbranch+"' where id="+studentid;
    	    	 stmt.executeUpdate(sql);*/
   
    	           {
    	             System.out.println("     "+sid1+"     "+"   "
    	            		 +branch1+"     "+"    "+
    	            		 clsrm1+"     "+"    "+seatno1+"      "+"      "+sname1);
    	             count++;
    	           }
     	      }
	      }
	    
	    	  if(count<=0)
   	        {
	    		  System.out.println();
   	        	System.out.println("wrong details!");
   	        	System.out.println("Please enter correct details to login..");
   	        }
	      
		
       }
	      catch(Exception e)
	      {
	    	  System.out.println(e);
	      }
		
	}
	

	

	

}
