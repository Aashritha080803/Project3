package esa;
import java.sql.*;
import esa.classroom;
public class admin {
	
	public static boolean adminlogin(Statement stmt,String adminid,String adminpswd)
	{
		
		try {
			
		    ResultSet ad=stmt.executeQuery("select * from Admin");
		    String usname;
		    String pswd;
	
		while(ad.next())
		{
			usname=ad.getString("username");
			pswd=ad.getString("password");
			if(usname.equals(adminid) && pswd.equals(adminpswd))
			{
		
			   
				return true;
			}
			
	     }
		
			
		}
		catch (Exception e)
		{
			System.out.println(e);
			}
		
		return false;
		
	
	}
	public static void displaytable(Statement stmt)
	{
		classroom.displayClassroom(stmt, 201);
		classroom.displayClassroom(stmt, 202);
	}
	
	public static void displaystudents(Statement stmt,Connection con)
	{
		try {
			
		 ResultSet rs=stmt.executeQuery("select * from Student_Details");
 	    
	        int sid;
         String sname;
         String clsrm;
         int seatno;
         String paswd;
         String branch;
         
         System.out.println("STUDENT ID    PASSWORD     BRANCH    CLASSROOM    SEAT NUMBER	STUDENT NAME");
         while(rs.next())
 	    {
 	        sid=rs.getInt("id");
 	        paswd=rs.getString("password");
 	        branch=rs.getString("branch");
 	        sname=rs.getString("name");
 	        clsrm=rs.getString("classroom");
 	        seatno=rs.getInt("seat");
 	    
 	        classroom.allocateclass(sid,con);
 	        
 	        System.out.println("     "+sid+"     "+"   "+paswd+"    "+"    "
 	        		+branch+"     "+"    "+clsrm+"     "+"    "+seatno+"      "+"      "+sname);

 	     }
   
         stmt.close();
         rs.close();
         
 
      }
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
	
