package esa;
import java.sql.*;


public class classroom {
	static int capacity=15;
	static int clsrm=201;
	static int count=0;
	
	public static void allocateclass(int stid,Connection con)
	{
		
		
		try {
			Statement stmt=con.createStatement();

				     	    if(count<capacity)
				     	    {
				     	    	String sql="update student_details set seat = "+(count+1)+" where id= "+stid;
				     	    	String sql1="update student_details set classroom = "+clsrm+" where id= "+stid;
				     	    	count++;
				     	    	stmt.executeUpdate(sql);
				     	    	stmt.executeUpdate(sql1);
				     	    	
				     	    	
				     	    }
				     	    else 
				     	    {
				     	    	clsrm++;
				     	    	count=0;
				     	    	String sql="update student_details set seat = "+(count+1)+" where id= "+stid;
				     	    	String sql1="update student_details set classroom = "+clsrm+" where id= "+stid;
				     	    	count++;
				     	    	stmt.executeUpdate(sql);
				     	    	stmt.executeUpdate(sql1);
				     	    }
		   
		            
		 
		}
		catch(Exception e)
		{
			
		}
	}
	 public static void displayClassroom(Statement stmt, int classroomNumber) {
	        try {
	           
	        	
	            int numRows = 5;
	            int numColumns = 3;
	      
	            System.out.println("Classroom " + classroomNumber + " Seating Arrangement:");
	            System.out.println("-----------------------------------------------------");


	           
	                for(int i=1;i<=numRows;i++)
	                {
	                	for(int j=1;j<=numColumns;j++)
	                	{
	                		int seatNumber = (i - 1) + (j - 1) * numRows + 1;
	                    String sql = "SELECT id FROM student_details WHERE classroom = " +
	                     classroomNumber + " AND seat = " + seatNumber;
	                    
	                    ResultSet rs = stmt.executeQuery(sql);

	                    if (rs.next()) {
	                        int studentId = rs.getInt("id");
	                        System.out.printf(" | " +studentId+"-"+seatNumber);
	                    } else {
	                        System.out.printf(" | ", "Empty");
	                    }
	                 
	                }
	                System.out.println("|");
	                
	            }

	            System.out.println("-----------------------------------------------------");
	        } catch (Exception e) {
	            System.out.println(e);
	        }
	    }

	
}
