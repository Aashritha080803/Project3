package esa;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import esa.admin;
import esa.classroom;

public class maincode {

	public static void main(String[] args) {
try {
            
			Connection con;
			//classroom c;
			Class.forName("com.mysql.cj.jdbc.Driver");
	        con= DriverManager.getConnection("jdbc:mysql://localhost:3306/javaproject","root","manu709*");
	        Statement stmt=con.createStatement();
	        Scanner sc=new Scanner(System.in);
            System.out.println("USER TYPES:");
            System.out.println("1.Admin");
            System.out.println("2.Student");
            System.out.print("Enter an option(1/2) to select user mode:");
            int n=sc.nextInt();
            System.out.println();
            switch(n)
            {
        	   case 1:
        		   Statement stmt1=con.createStatement();
        		  
        		System.out.println("ADMIN LOGIN");
        		System.out.print("Enter username:");
        		String adminid=sc.next();
        		System.out.print("Enter password:");
        		String adminpswd=sc.next();
        		boolean adminloggedin=admin.adminlogin(stmt,adminid,adminpswd);
				if(adminloggedin)
				{
	        		System.out.println("Display :");
	        		System.out.println("1.Stuent database");
	        		System.out.println("2.Classroom Seating Arrangement");
	        		System.out.print("Enter your choice:");
	        		int s=sc.nextInt();
	        		switch(s)
	        		{
        				case 1:
        				
	        				
        					admin.displaystudents(stmt,con);
	        				break;
        				case 2:
	        				admin.displaytable(stmt1);
	        				break;
					}
				}
        		  
        	
        				else
        				{
		        			System.out.println();
		    		        System.out.println("wrong details!");
		    				System.out.println("Please enter correct details to login..");
        				}
        		break;
        	   case 2:
        		   	System.out.println("STUDENT LOGIN");
           			System.out.print("Enter your login id:");
           			int studentid=sc.nextInt();
           			System.out.print("Enter password: ");
           			String studentpswd=sc.next();
           			System.out.print("Enter Branch: ");
           			String branchname=sc.next();
           			student.studentloginanddisplay(stmt, studentid, studentpswd);
           			break;
        	  
        		  
        	   default:
        		   System.out.println("exited");
             }
		}
            catch(Exception e)
            {
            	System.out.println(e);
            }

	}

}
